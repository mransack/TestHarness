import { Card, CardBody, CardTitle, Container, Row, Col } from "reactstrap";
import Select from "react-select";
import React, {useState} from 'react';
import Button from "reactstrap";

const insCarrierLists = [
  { label: 'Banner Health', value: 'Banner Health' },
  { label: 'AvMed Health', value: 'AvMed Health' },
  { label: 'Apollo Health', value: 'Apollo Health' },
  { label: 'Cigna Health', value: 'Cigna Health' },
  
];

const eventLists = [
  { value: '1', label: 'Approval' },
  { value: '2', label: 'Denial' },
  { value: '3', label: 'Partial Denial' },
];
// const [caseEvents,setCaseEvent] = useState({});
// const [insCarrier,setInsCarrier] = useState({}); 
const HandleEventChange =(obj)=>{
  //setCaseEvent(obj);
  console.log(obj);
}

const HandleInsCarrierChange =(obj)=>{
  //setInsCarrier(obj);
  console.log(obj);
}

const Header = () => {
  return (
    <>
      <div className="header bg-gradient-info pb-8 pt-5 pt-md-8">
        <Container fluid>
          <div className="header-body">
            <Row>
              <Col lg="6" xl="1" >
                <div className="mb-4 mb-xl-0 p-2">
                  <label>HealthPlan</label>
                </div>
              </Col>
              <Col lg="6" xl="3">
                <Card className="card-stats mb-4 mb-xl-0 noborder">
                <Select
        options={insCarrierLists}
        onChange = {(option)=>HandleInsCarrierChange(option)}
      />
                </Card>
              </Col>
              <Col lg="6" xl="1" >
                <div className="mb-4 mb-xl-0 p-2">
                  <label>Events</label>
                </div>
              </Col>
              <Col lg="6" xl="3">
                <Card className="card-stats mb-4 mb-xl-0 noborder">
                <Select
        options={eventLists}
        onChange={(option)=>HandleEventChange(option)}
      />
                </Card>
              </Col>
              <Col lg="6" xl="2">
                <div className="card-stats mb-4 mb-xl-0">
                <button variant="contained" color="primary" className="custom-primary-button">
        Search
      </button>
                </div>
              </Col>
              <Col lg="6" xl="2">
                <div className="card-stats mb-4 mb-xl-0">
                <button variant="contained" color="primary" className="custom-primary-button">
        Run Test
      </button>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </div>
    </>
  );
};
function changeEvents(){
  console.log(this.val);
}

export default Header;
