import { Container, Row, Col, Nav, NavItem, NavLink } from "reactstrap";

const Footer = () => {
  return (
    <footer className="footer">
      <Row className="align-items-center justify-content-xl-between">
        <Col xl="4">
          
        </Col>
        <Col xl="4">
          <div className="copyright text-center text-xl-center text-muted">
            © 1994-{new Date().getFullYear()}{" "}
            <a
              className="font-weight-bold ml-1 disabled-link"
              href="#"
              rel="noopener noreferrer"
              target="_blank"
            >
              eviCore
            </a>
          </div>
        </Col>

        <Col xl="4">
          
        </Col>
      </Row>
    </footer>
  );
};

export default Footer;
