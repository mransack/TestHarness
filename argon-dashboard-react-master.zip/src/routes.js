import MergeRules from "views/Rules/MergeRules";
var routes = [
  {
    path: "/mergedrules",
    name: "Merged Rules",
    icon: "ni ni-bullet-list-67 text-red",
    component: MergeRules,
    layout: "/admin",
  }
];
export default routes;
